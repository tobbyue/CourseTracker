Testing

The feedback module was tested using Django unit tests to verify both model behaviour and user-facing functionality.

The test coverage includes:
- enrolled students being able to access the rating page,
- non-enrolled students being prevented from submitting ratings,
- successful submission of ratings by enrolled students,
- updating an existing rating instead of creating duplicate entries,
- correct rendering of the course reviews page,
- enforcement of the one-rating-per-student-per-course constraint, and
- correct calculation of average course rating.

All feedback tests passed successfully using the command:
python3 manage.py test feedback


Accessibility

Accessibility was considered across key user-facing pages of the application, especially the login/register pages, the task detail page, and the course rating interface.

Several accessibility features were implemented or confirmed in the current system. These include a skip link to bypass repeated navigation, visible focus styles for interactive elements, clear error identification on form-based pages, and semantic HTML structure to improve interpretation by assistive technologies. ARIA-related support is also used in important interactive components.

In addition, the task detail page was improved with a live status message using aria-live="polite" so that task completion state is communicated more clearly. The course rating page was also improved with a short guidance text to help users understand how to provide a rating and optional comment.

Accessibility evidence was supported by page screenshots, code-level examples, and Lighthouse baseline results for selected pages.